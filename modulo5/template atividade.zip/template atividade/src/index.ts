import {app} from "./app"



app.get("/", async function(){
   console.log("endpoint teste")
})


